from django.urls import path
from .views import  exit
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('inicio.html/', views.inicio, name='inicio'),
    path('noticias.html/', views.noticias, name ='noticias'),
    path('nosotros.html/', views.nosotros, name ='nosotros'),
    path('formulario.html/', views.formulario, name ='formulario'),
    path('api.html/', views.api, name ='api'),
    path('home.html/', views.home, name ='home'),
    path('productos/', views.productos, name ='productos'),
    path('logout/', exit, name='exit'),

 #URL CRUD
    path('crud/', views.crud, name='crud'),
    path('crud/agregar/', views.agregar, name='agregar'),
    path('crud/agregarrec/',views.agregarrec, name='agregarrec'),
    path('crud/eliminar/<int:id>/', views.eliminar, name='eliminar'),
    path('crud//<int:id>/', views.actualizar, name='actualizar'),
    path('crud/actualizarrec/<int:id>/', views.actualizarrec, name='actualizarrec')
]