from django.contrib import admin
from .models import Alumno

# Register your models here.
class AlumnoAdmin(admin.ModelAdmin):
    list_display="nombre","apellido","comuna"

admin.site.register(Alumno,AlumnoAdmin)
